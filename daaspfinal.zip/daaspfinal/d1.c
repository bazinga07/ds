#include<stdio.h>
#include<stdlib.h>
int **A,**B,**C;
int **A11,**B11,**C11;
int **A12,**B12,**C12;
int **A21,**B21,**C21;
int **A22,**B22,**C22;
int **p,**q,**r,**s,**t,**u,**v,i,j,k,n;
int strassen(int **A,int **B);

int **add(int **mat1,int **mat2,int x)
{
	//Dynamic memory allocation for matrix
	int **z=(int**) malloc(sizeof(int*)*x);
    for(i=0;i<x;i++)
		z[i]=malloc(sizeof(int)*x);

	//Addition of matrices
   	for(i=0;i<x;i++)
		for(j=0;j<x;j++)
			z[i][j]=mat1[i][j]+mat2[i][j];

	return z;
}	

int **sub(int **mat1,int **mat2,int x)
{
	//Dynamic memory allocation for matrix
	int **z=(int**) malloc(sizeof(int*)*x);
    for(i=0;i<x;i++)
		z[i]=malloc(sizeof(int)*x);

	//Subtraction of matrices
   	for(i=0;i<x;i++)
		for(j=0;j<x;j++)
			z[i][j]=mat1[i][j]-mat2[i][j];

	return z;
}	

int **mult(int **mat1,int **mat2,int x)
{
	//Dynamic memory allocation for matrix
	int **z=(int**) malloc(sizeof(int*)*x);
    for(i=0;i<x;i++)
		z[i]=malloc(sizeof(int)*x);

	//Initializing matrix as zero matrix
   	for(i=0;i<x;i++)
		for(j=0;j<x;j++)
			z[i][j]=0;

	//Multiplication of matrices
   	for(i=0;i<x;i++)
		for(j=0;j<x;j++)
			for(k=0;k<x;k++)
				z[i][j]=z[i][j]+mat1[i][j]*mat2[i][j];

	return z;
}	

void main()
{
	printf("\nEnter order of matrix :\t");
	scanf("%d",&n);

	//Dynamic memory allocation for matrices
	A=(int**) malloc(sizeof(int*)*n);
    for(i=0;i<n;i++)
		A[i]=malloc(sizeof(int)*n);
	B=(int**) malloc(sizeof(int*)*n);
    for(i=0;i<n;i++)
		B[i]=malloc(sizeof(int)*n);
	C=(int**) malloc(sizeof(int*)*n);
    for(i=0;i<n;i++)
		C[i]=malloc(sizeof(int)*n);

	//Accepting input matrices of order n
	printf("\nPlease enter first matrix :\n");
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)
			scanf("%d",&A[i][j]);
	printf("\nPlease enter second matrix :\n");
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)
			scanf("%d",&B[i][j]);
	
	strassen(A,B);//strassen function call  

	//Displaying resultant matrix
	printf("\nResultant matrix :\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
			printf("%d\t",C[i][j]);
		printf("\n");
	}
	printf("\n\n");

}

int strassen(int **A,int **B)
{
	//Dynamic memory allocation for matrices
	A11=(int**) malloc(sizeof(int*)*n/2);
    for(i=0;i<n/2;i++)
		A11[i]=malloc(sizeof(int)*n/2);
	B11=(int**) malloc(sizeof(int*)*n/2);
    for(i=0;i<n/2;i++)
		B11[i]=malloc(sizeof(int)*n/2);
	A12=(int**) malloc(sizeof(int*)*n/2);
    for(i=0;i<n/2;i++)
		A12[i]=malloc(sizeof(int)*n/2);
	B12=(int**) malloc(sizeof(int*)*n/2);
    for(i=0;i<n/2;i++)
		B12[i]=malloc(sizeof(int)*n/2);
	A21=(int**) malloc(sizeof(int*)*n/2);
    for(i=0;i<n/2;i++)
		A21[i]=malloc(sizeof(int)*n/2);
	B21=(int**) malloc(sizeof(int*)*n/2);
    for(i=0;i<n/2;i++)
		B21[i]=malloc(sizeof(int)*n/2);
	A22=(int**) malloc(sizeof(int*)*n/2);
    for(i=0;i<n/2;i++)
		A22[i]=malloc(sizeof(int)*n/2);
	B22=(int**) malloc(sizeof(int*)*n/2);
    for(i=0;i<n/2;i++)
		B22[i]=malloc(sizeof(int)*n/2);

	//Dividing the first input matrix		
	for(i=0;i<n/2;i++)
		for(j=0;j<n/2;j++)
			A11[i][j]=A[i][j];
	for(i=0;i<n/2;i++)
		for(j=n/2;j<n;j++)
			A12[i][j-n/2]=A[i][j];
	for(i=n/2;i<n;i++)
		for(j=0;j<n/2;j++)
			A21[i-n/2][j]=A[i][j];
	for(i=n/2;i<n;i++)
		for(j=n/2;j<n;j++)
			A22[i-n/2][j-n/2]=A[i][j];

	//Dividing the second input matrix		
	for(i=0;i<n/2;i++)
		for(j=0;j<n/2;j++)
			B11[i][j]=B[i][j];
	for(i=0;i<n/2;i++)
		for(j=n/2;j<n;j++)
			B12[i][j-n/2]=B[i][j];
	for(i=n/2;i<n;i++)
		for(j=0;j<n/2;j++)
			B21[i-n/2][j]=B[i][j];
	for(i=n/2;i<n;i++)
		for(j=n/2;j<n;j++)
			B22[i-n/2][j-n/2]=B[i][j];

	//Calculating matrices p,q,r,s,t,u,v,c11,c12,c21,c22 using strassen's method
  	p=mult(add(A11,A22,n/2),add(B11,B22,n/2),n/2);
  	q=mult(add(A21,A22,n/2),B11,n/2);
  	r=mult(A11,sub(B12,B22,n/2),n/2);
  	s=mult(A22,sub(B21,B11,n/2),n/2);
  	t=mult(add(A11,A12,n/2),B22,n/2);
  	u=mult(sub(A21,A11,n/2),add(B11,B12,n/2),n/2);
 	v=mult(sub(A12,A22,n/2),add(B21,B22,n/2),n/2);
 	
   	C11=add(sub(add(p,s,n/2),t,n/2),v,n/2);
   	C22=add(sub(add(p,r,n/2),q,n/2),u,n/2);
   	C12=add(r,t,n/2);
	C21=add(q,s,n/2);

	//Combining the matrices c11,c12,c21,c22 to get resultant matrix
	for(i=0;i<n/2;i++)
		for(j=0;j<n/2;j++)
			C[i][j]=C11[i][j];
	for(i=0;i<n/2;i++)
		for(j=n/2;j<n;j++)
			C[i][j]=C12[i][j-n/2];
	for(i=n/2;i<n;i++)
		for(j=0;j<n/2;j++)
			C[i][j]=C21[i-n/2][j];
	for(i=n/2;i<n;i++)
		for(j=n/2;j<n;j++)
			C[i][j]=C22[i-n/2][j-n/2];

}
