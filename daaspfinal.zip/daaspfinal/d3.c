#include<stdio.h>
#include<stdlib.h>
void check(int,int);
int cost[10][10],P[10][10],D[10][10];
int i,j,k,n,final;
int v1,v2,distance,x,y;


int main()
{
    printf("\nEnter the no of vertices in that graph:-");
    scanf("%d",&n);
    printf("\nEnter the cost of each:-\n");
    for(i=0;i<n;i++)
    {
    	for(j=0;j<n;j++)
    	{
    		if(i==j)
    		{
    			printf("\nEnter the Zero:- ");
    			scanf("%d",&cost[i][j]);
    		}
    		else
    		{
    			printf("\nEnter the value other than Zero:-");
    			scanf("%d",&cost[i][j]);
    		}

    	}
    
    }
    printf("====================================================================");
    printf("\nThe graph you have entered:-\n");
    for(i=0;i<n;i++)
    {
    	for(j=0;j<n;j++)
    	{
    		printf("%d\t",cost[i][j]);
    	}
    	printf("\n");
    }
    printf("====================================================================");
    
    for(i=0;i<n;i++)
    {
    	for(j=0;j<n;j++)
    	{
    		P[i][j]=0;
    	}
    }


    for(k=0;k<n;k++)
    {
    	for(i=0;i<n;i++)
    	{
    		for(j=0;j<n;j++)
    		{
    			if((cost[i][k]+cost[k][j])<(cost[i][j]))
    			{
    				D[i][j]=cost[i][k]+cost[k][j];
    				P[i][j]=k;
    			}
    			else
    			{
    				D[i][j]=cost[i][j];
    				P[i][k]=cost[i][j];
    			}

    		}
    	}

    	printf("\n");
    	for(x=0;x<n;x++)
    	{
    		for(y=0;y<n;y++)
    		{
    			cost[x][y]=D[x][y];
    			printf("%d\t",cost[x][y]);
    		}
    		printf("\n");
    	}
    }

    printf("\n");
    printf("\nThe Path matrix is:-\n");
    for(i=0;i<n;i++)
    {
    	for(j=0;j<n;j++)
    	{
    		printf("%d\t",P[i][j]);
    	}
    	printf("\n");
    }
    
    printf("\nEnter the vertices for finding Path and minimun distance:");
    scanf("%d %d",&v1,&v2);
    final=v2;
    distance=D[v1][v2];
    printf("\nThe minimum distance is %d and Path is:-%d",distance,v1);
    check(v1,v2);
    printf("\n");
    
    printf("====================================================================\n");
return 0;
}

void check(int v1,int v2)
{
	if(P[v1][v2]==0)
	{
		printf("->%d",v2);
		v1=v2;
		if(v1!=final)
			check(v1,final);
	}
	else
	{
		v2=P[v1][v2];
		if(v2!=0)
			check(v1,v2);
	}
}
